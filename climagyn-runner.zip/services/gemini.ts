import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.GEMINI_API_KEY;

export const getVictoryInsight = async (score: number, distance: number, gems: number) => {
  if (!apiKey) {
    return "The forest is ancient and full of life. You have walked its paths well.";
  }

  try {
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: "gemini-2.0-flash-exp",
      contents: `The player has completed the Forest Runner journey. 
      Stats: 
      Score: ${score}
      Distance: ${distance} meters
      Gems Collected: ${gems}
      
      Write a short, poetic, and inspiring 'Nature Insight' (max 2 sentences) about their journey through the lush, mystical forest. 
      The tone should be organic, serene, and philosophical.`,
    });

    return response.text || "Your journey has left a trail of growth across the forest floor.";
  } catch (error) {
    console.error("Error generating victory insight:", error);
    return "The leaves whisper of your passage, though their secrets remain with the trees.";
  }
};
