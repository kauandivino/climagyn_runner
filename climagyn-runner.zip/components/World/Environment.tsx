/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useStore } from '../../store';
import { RUN_SPEED_BASE, LANE_WIDTH } from '../../types';

const Tree: React.FC<{ position: [number, number, number]; scale?: number; type?: number }> = ({ position, scale = 1, type = 0 }) => {
    const trunkGeo = useMemo(() => new THREE.CylinderGeometry(0.2, 0.4, 2, 8), []);
    const leavesGeo = useMemo(() => new THREE.ConeGeometry(1.5, 3, 8), []);
    const roundLeavesGeo = useMemo(() => new THREE.SphereGeometry(1.2, 8, 8), []);
    
    return (
        <group position={position} scale={scale}>
            <mesh position={[0, 1, 0]} geometry={trunkGeo}>
                <meshStandardMaterial color="#3d2b1f" roughness={0.9} />
            </mesh>
            {type === 0 ? (
                <>
                    <mesh position={[0, 3, 0]} geometry={leavesGeo}>
                        <meshStandardMaterial color="#1a4d1a" roughness={0.8} />
                    </mesh>
                    <mesh position={[0, 4.5, 0]} geometry={leavesGeo} scale={0.7}>
                        <meshStandardMaterial color="#2d5a27" roughness={0.8} />
                    </mesh>
                </>
            ) : (
                <>
                    <mesh position={[0, 2.5, 0]} geometry={roundLeavesGeo} scale={[1.2, 0.8, 1.2]}>
                        <meshStandardMaterial color="#145214" roughness={0.8} />
                    </mesh>
                    <mesh position={[0.8, 3.2, 0]} geometry={roundLeavesGeo} scale={0.6}>
                        <meshStandardMaterial color="#1e631e" roughness={0.8} />
                    </mesh>
                    <mesh position={[-0.6, 3.5, 0.5]} geometry={roundLeavesGeo} scale={0.5}>
                        <meshStandardMaterial color="#2a7a2a" roughness={0.8} />
                    </mesh>
                </>
            )}
        </group>
    );
};

const Plant: React.FC<{ position: [number, number, number]; scale?: number }> = ({ position, scale = 1 }) => {
    const leafGeo = useMemo(() => new THREE.SphereGeometry(0.3, 8, 8), []);
    return (
        <group position={position} scale={scale}>
            <mesh position={[0, 0.2, 0]} geometry={leafGeo} scale={[1, 0.5, 1]}>
                <meshStandardMaterial color="#3a5f0b" />
            </mesh>
            <mesh position={[0.2, 0.1, 0.2]} geometry={leafGeo} scale={[0.8, 0.4, 0.8]}>
                <meshStandardMaterial color="#4a7f0e" />
            </mesh>
        </group>
    );
};

const ForestFloor: React.FC = () => {
    const speed = useStore(state => state.speed);
    const meshRef = useRef<THREE.Mesh>(null);

    useFrame((state, delta) => {
        if (meshRef.current) {
            const mat = meshRef.current.material as THREE.MeshStandardMaterial;
            if (mat.map) {
                mat.map.offset.y -= (speed / RUN_SPEED_BASE) * delta * 0.5;
            }
        }
    });

    const grassTexture = useMemo(() => {
        const canvas = document.createElement('canvas');
        canvas.width = 512;
        canvas.height = 512;
        const ctx = canvas.getContext('2d')!;
        
        // Base green
        ctx.fillStyle = '#1e3a1e';
        ctx.fillRect(0, 0, 512, 512);
        
        // Noise/Grass blades
        for (let i = 0; i < 5000; i++) {
            ctx.fillStyle = `rgba(40, ${80 + Math.random() * 40}, 30, 0.3)`;
            ctx.fillRect(Math.random() * 512, Math.random() * 512, 2, 10);
        }
        
        const tex = new THREE.CanvasTexture(canvas);
        tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
        tex.repeat.set(1, 20);
        return tex;
    }, []);

    return (
        <mesh 
            ref={meshRef}
            rotation={[-Math.PI / 2, 0, 0]} 
            position={[0, -0.01, -50]} 
            receiveShadow
        >
            <planeGeometry args={[40, 200]} />
            <meshStandardMaterial map={grassTexture} roughness={1} />
        </mesh>
    );
};

const ForestBackground: React.FC = () => {
    const trees = useMemo(() => {
        const result = [];
        for (let i = 0; i < 120; i++) {
            const side = Math.random() > 0.5 ? 1 : -1;
            result.push({
                pos: [
                    (6 + Math.random() * 20) * side,
                    0,
                    -Math.random() * 200
                ] as [number, number, number],
                scale: 0.8 + Math.random() * 2.5,
                type: Math.random() > 0.5 ? 1 : 0
            });
        }
        return result;
    }, []);

    const plants = useMemo(() => {
        const result = [];
        for (let i = 0; i < 200; i++) {
            const side = Math.random() > 0.5 ? 1 : -1;
            result.push({
                pos: [
                    (3 + Math.random() * 25) * side,
                    0,
                    -Math.random() * 200
                ] as [number, number, number],
                scale: 0.5 + Math.random() * 1.5
            });
        }
        return result;
    }, []);

    return (
        <group>
            {trees.map((t, i) => <Tree key={i} position={t.pos} scale={t.scale} type={t.type} />)}
            {plants.map((p, i) => <Plant key={i} position={p.pos} scale={p.scale} />)}
        </group>
    );
};

const NaturalSun: React.FC = () => {
    return (
        <group position={[0, 40, -150]}>
            <mesh>
                <sphereGeometry args={[15, 32, 32]} />
                <meshBasicMaterial color="#fff5cc" />
            </mesh>
            <pointLight intensity={2} distance={300} color="#fff5cc" />
        </group>
    );
};

const PathGuides: React.FC = () => {
    const { laneCount } = useStore();
    const separators = useMemo(() => {
        const lines: number[] = [];
        const startX = -(laneCount * LANE_WIDTH) / 2;
        for (let i = 0; i <= laneCount; i++) {
            lines.push(startX + (i * LANE_WIDTH));
        }
        return lines;
    }, [laneCount]);

    return (
        <group position={[0, 0.01, 0]}>
            {separators.map((x, i) => (
                <mesh key={`sep-${i}`} position={[x, 0, -50]} rotation={[-Math.PI / 2, 0, 0]}>
                    <planeGeometry args={[0.1, 200]} />
                    <meshStandardMaterial color="#3d2b1f" transparent opacity={0.4} />
                </mesh>
            ))}
        </group>
    );
};

export const Environment: React.FC = () => {
  return (
    <>
      <color attach="background" args={['#0a1a0a']} />
      <fog attach="fog" args={['#0a1a0a', 20, 120]} />
      
      <ambientLight intensity={0.5} color="#a0ffa0" />
      <directionalLight 
        position={[10, 20, 10]} 
        intensity={1.2} 
        color="#ffffff" 
        castShadow 
        shadow-mapSize={[1024, 1024]}
      />
      
      <ForestFloor />
      <ForestBackground />
      <PathGuides />
      <NaturalSun />
    </>
  );
};
