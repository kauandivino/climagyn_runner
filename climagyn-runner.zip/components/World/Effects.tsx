/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React from 'react';
import { EffectComposer, Bloom, Vignette, Noise, ChromaticAberration } from '@react-three/postprocessing';
import { BlendFunction } from 'postprocessing';
import { useStore } from '../../store';
import { RUN_SPEED_BASE } from '../../types';

export const Effects: React.FC = () => {
  const speed = useStore(state => state.speed);
  const aberrationOffset = Math.max(0, (speed / RUN_SPEED_BASE - 1) * 0.002); // Reduced from 0.005

  return (
    <EffectComposer multisampling={0}>
      {/* Softer bloom for forest atmosphere */}
      <Bloom 
        luminanceThreshold={0.8} 
        mipmapBlur 
        intensity={0.5} // Reduced from 1.0
        radius={0.4}
        levels={8}
      />
      <Noise opacity={0.03} blendFunction={BlendFunction.OVERLAY} />
      <Vignette eskil={false} offset={0.2} darkness={0.4} />
      <ChromaticAberration 
        blendFunction={BlendFunction.NORMAL} 
        offset={[aberrationOffset, aberrationOffset] as any} 
      />
    </EffectComposer>
  );
};
