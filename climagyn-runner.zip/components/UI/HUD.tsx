/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React, { useState, useEffect } from 'react';
import { Heart, Zap, Trophy, MapPin, Diamond, Leaf, Play, Send } from 'lucide-react';
import { useStore } from '../../store';
import { GameStatus, GEMINI_COLORS, RUN_SPEED_BASE } from '../../types';
import { audio } from '../System/Audio';
import { getVictoryInsight } from '../../services/gemini';
import { submitScore, getTopScores, LeaderboardEntry } from '../../firebase';

const Leaderboard: React.FC<{ entries: (LeaderboardEntry & { id: string })[] }> = ({ entries }) => {
    return (
        <div className="w-full max-w-md bg-black/40 backdrop-blur-md border border-white/10 rounded-2xl overflow-hidden mt-6">
            <div className="bg-white/5 px-4 py-2 border-b border-white/10 flex justify-between items-center">
                <h3 className="text-sm font-bold tracking-widest text-emerald-400">LEADERBOARD</h3>
                <Trophy className="w-4 h-4 text-yellow-400" />
            </div>
            <div className="max-h-48 overflow-y-auto">
                {entries.length === 0 ? (
                    <div className="p-4 text-center text-gray-500 text-xs">No entries yet. Be the first!</div>
                ) : (
                    entries.map((entry, idx) => (
                        <div key={entry.id} className={`flex items-center justify-between px-4 py-3 border-b border-white/5 last:border-0 ${idx === 0 ? 'bg-yellow-400/5' : ''}`}>
                            <div className="flex items-center space-x-3">
                                <span className={`text-xs font-mono w-4 ${idx < 3 ? 'text-yellow-400 font-bold' : 'text-gray-500'}`}>
                                    {idx + 1}
                                </span>
                                <span className="text-sm font-medium text-white truncate max-w-[120px]">{entry.playerName}</span>
                            </div>
                            <div className="flex flex-col items-end">
                                <span className="text-sm font-bold text-emerald-400 font-mono">{entry.score.toLocaleString()}</span>
                                <span className="text-[10px] text-gray-500">LVL {entry.level}</span>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};

export const HUD: React.FC = () => {
  const { score, lives, maxLives, collectedLetters, status, level, restartGame, startGame, gemsCollected, distance, speed, victoryInsight, setVictoryInsight } = useStore();
  const target = ['C', 'L', 'I', 'M', 'A', 'G', 'Y', 'N'];
  
  const [playerName, setPlayerName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [hasSubmitted, setHasSubmitted] = useState(false);
  const [leaderboard, setLeaderboard] = useState<(LeaderboardEntry & { id: string })[]>([]);
  const [showRanking, setShowRanking] = useState(false);

  useEffect(() => {
    if (status === GameStatus.VICTORY && !victoryInsight) {
      const fetchInsight = async () => {
        const insight = await getVictoryInsight(score, distance, gemsCollected);
        setVictoryInsight(insight);
      };
      fetchInsight();
    }
    
    // Fetch leaderboard when game ends or menu is active
    if (status === GameStatus.GAME_OVER || status === GameStatus.VICTORY || status === GameStatus.MENU) {
        const fetchLeaderboard = async () => {
            const scores = await getTopScores(10);
            setLeaderboard(scores);
        };
        fetchLeaderboard();
    }
    
    if (status !== GameStatus.MENU) {
        setShowRanking(false);
    }

    if (status === GameStatus.PLAYING) {
        // Reset submission state when game starts
        setHasSubmitted(false);
        setPlayerName('');
    }
  }, [status, score, distance, gemsCollected, victoryInsight, setVictoryInsight]);

  const handleScoreSubmit = async (e: React.FormEvent) => {
      e.preventDefault();
      if (!playerName.trim() || isSubmitting || hasSubmitted) return;

      setIsSubmitting(true);
      try {
          await submitScore({
              playerName: playerName.trim(),
              score,
              level,
              distance
          });
          setHasSubmitted(true);
          // Refresh leaderboard
          const scores = await getTopScores(10);
          setLeaderboard(scores);
      } catch (error) {
          console.error("Failed to submit score", error);
      } finally {
          setIsSubmitting(false);
      }
  };

  // Common container style
  const containerClass = "absolute inset-0 pointer-events-none flex flex-col justify-between p-4 md:p-8 z-50";

  if (status === GameStatus.MENU) {
      return (
          <div className="absolute inset-0 flex items-center justify-center z-[100] bg-black/80 backdrop-blur-sm p-4 pointer-events-auto">
              {/* Card Container */}
              <div className="relative w-full max-w-4xl rounded-[2.5rem] overflow-hidden shadow-[0_0_100px_rgba(16,185,129,0.2)] border border-white/10 animate-in zoom-in-95 duration-700">
                
                {/* Image Container */}
                <div className="relative w-full aspect-video bg-gray-900">
                     <img 
                      src="https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=1280&q=80" 
                      alt="Climagyn Runner Cover" 
                      className="w-full h-full object-cover opacity-90"
                      referrerPolicy="no-referrer"
                     />
                     
                     {/* Gradient Overlay */}
                     <div className="absolute inset-0 bg-gradient-to-t from-[#050011] via-black/10 to-transparent"></div>
                     <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-transparent"></div>
                     
                     {/* Title Overlay - Moved higher to not cover the character/path */}
                     <div className="absolute inset-0 flex flex-col items-center justify-start pt-16 md:pt-24 p-8">
                        <h1 className="text-6xl md:text-8xl font-black text-white tracking-[0.3em] drop-shadow-[0_0_30px_rgba(16,185,129,0.9)] font-cyber text-center">
                            CLIMAGYN<br/>
                            <span className="text-emerald-400">RUNNER</span>
                        </h1>
                        <div className="h-1.5 w-48 bg-emerald-500 mt-8 rounded-full shadow-[0_0_20px_#10b981] animate-pulse"></div>
                     </div>

                     {/* Bottom Controls */}
                     <div className="absolute bottom-0 left-0 right-0 p-8 md:p-12 flex flex-col items-center bg-gradient-to-t from-black/80 to-transparent">
                        <button 
                          onClick={() => { audio.init(); startGame(); }}
                          className="w-full max-w-md group relative px-8 py-5 bg-emerald-500 text-black font-black text-2xl rounded-2xl hover:bg-emerald-400 transition-all shadow-[0_0_40px_rgba(16,185,129,0.4)] hover:scale-105 overflow-hidden"
                        >
                            <div className="absolute inset-0 bg-white/20 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-500"></div>
                            <span className="relative z-10 tracking-[0.2em] flex items-center justify-center">
                                PLAY <Play className="ml-3 w-6 h-6 fill-black" />
                            </span>
                        </button>

                        <div className="flex items-center space-x-8 mt-6">
                            <p className="text-emerald-400/80 text-xs md:text-sm font-mono tracking-[0.2em] uppercase">
                                [ ARROWS / SWIPE TO MOVE ]
                            </p>
                            <div className="h-4 w-px bg-white/20"></div>
                            <p className="text-emerald-400/80 text-xs md:text-sm font-mono tracking-[0.2em] uppercase">
                                [ SPACE TO JUMP ]
                            </p>
                        </div>
                     </div>
                </div>
              </div>
          </div>
      );
  }

  if (status === GameStatus.GAME_OVER) {
      return (
          <div className="absolute inset-0 bg-black/90 z-[100] text-white pointer-events-auto backdrop-blur-sm overflow-y-auto">
              <div className="flex flex-col items-center justify-center min-h-full py-8 px-4">
                <h1 className="text-4xl md:text-6xl font-black text-white mb-6 drop-shadow-[0_0_10px_rgba(255,0,0,0.8)] font-cyber text-center">GAME OVER</h1>
                
                <div className="grid grid-cols-1 gap-3 md:gap-4 text-center mb-6 w-full max-w-md">
                    <div className="bg-gray-900/80 p-3 md:p-4 rounded-lg border border-gray-700 flex items-center justify-between">
                        <div className="flex items-center text-yellow-400 text-sm md:text-base"><Trophy className="mr-2 w-4 h-4 md:w-5 md:h-5"/> LEVEL</div>
                        <div className="text-xl md:text-2xl font-bold font-mono">{level} / 3</div>
                    </div>
                    <div className="bg-gray-900/80 p-3 md:p-4 rounded-lg border border-gray-700 flex items-center justify-between">
                        <div className="flex items-center text-cyan-400 text-sm md:text-base"><Diamond className="mr-2 w-4 h-4 md:w-5 md:h-5"/> GEMS COLLECTED</div>
                        <div className="text-xl md:text-2xl font-bold font-mono">{gemsCollected}</div>
                    </div>
                    <div className="bg-gray-900/80 p-3 md:p-4 rounded-lg border border-gray-700 flex items-center justify-between">
                        <div className="flex items-center text-purple-400 text-sm md:text-base"><MapPin className="mr-2 w-4 h-4 md:w-5 md:h-5"/> DISTANCE</div>
                        <div className="text-xl md:text-2xl font-bold font-mono">{Math.floor(distance)} LY</div>
                    </div>
                     <div className="bg-gray-800/50 p-3 md:p-4 rounded-lg flex items-center justify-between mt-2">
                        <div className="flex items-center text-white text-sm md:text-base">TOTAL SCORE</div>
                        <div className="text-2xl md:text-3xl font-bold font-cyber text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">{score.toLocaleString()}</div>
                    </div>
                </div>

                {!hasSubmitted ? (
                    <form onSubmit={handleScoreSubmit} className="w-full max-w-md mb-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                        <div className="relative">
                            <input 
                                type="text" 
                                value={playerName}
                                onChange={(e) => setPlayerName(e.target.value.slice(0, 20))}
                                placeholder="ENTER YOUR NAME"
                                className="w-full bg-white/5 border border-white/20 rounded-xl px-4 py-4 text-white font-bold tracking-widest focus:outline-none focus:border-emerald-500 transition-all pr-12"
                                required
                            />
                            <button 
                                type="submit"
                                disabled={isSubmitting || !playerName.trim()}
                                className="absolute right-2 top-2 bottom-2 px-3 bg-emerald-500 text-black rounded-lg hover:bg-emerald-400 transition-colors disabled:opacity-50"
                            >
                                <Send className="w-5 h-5" />
                            </button>
                        </div>
                        <p className="text-[10px] text-gray-500 mt-2 text-center tracking-widest">SUBMIT SCORE TO LEADERBOARD</p>
                    </form>
                ) : (
                    <div className="w-full max-w-md mb-6 p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-center animate-in zoom-in-95 duration-300">
                        <p className="text-emerald-400 font-bold tracking-widest text-sm">SCORE SUBMITTED!</p>
                    </div>
                )}

                <Leaderboard entries={leaderboard} />

                <button 
                  onClick={() => { audio.init(); restartGame(); }}
                  className="mt-8 px-8 md:px-10 py-3 md:py-4 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold text-lg md:text-xl rounded hover:scale-105 transition-all shadow-[0_0_20px_rgba(0,255,255,0.4)]"
                >
                    RUN AGAIN
                </button>
              </div>
          </div>
      );
  }

  if (status === GameStatus.VICTORY) {
    return (
        <div className="absolute inset-0 bg-gradient-to-b from-purple-900/90 to-black/95 z-[100] text-white pointer-events-auto backdrop-blur-md overflow-y-auto">
            <div className="flex flex-col items-center justify-center min-h-full py-8 px-4">
                <Leaf className="w-16 h-16 md:w-24 md:h-24 text-emerald-400 mb-4 animate-bounce drop-shadow-[0_0_15px_rgba(52,211,153,0.6)]" />
                <h1 className="text-3xl md:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-green-300 via-emerald-500 to-teal-500 mb-2 drop-shadow-[0_0_20px_rgba(34,197,94,0.6)] font-cyber text-center leading-tight">
                    JOURNEY COMPLETE
                </h1>
                <p className="text-emerald-300 text-sm md:text-2xl font-mono mb-8 tracking-widest text-center max-w-2xl px-4">
                    {victoryInsight || "THE FOREST HAS BEEN RESTORED"}
                </p>
                
                <div className="grid grid-cols-1 gap-4 text-center mb-6 w-full max-w-md">
                    <div className="bg-black/60 p-6 rounded-xl border border-yellow-500/30 shadow-[0_0_15px_rgba(255,215,0,0.1)]">
                        <div className="text-xs md:text-sm text-gray-400 mb-1 tracking-wider">FINAL SCORE</div>
                        <div className="text-3xl md:text-4xl font-bold font-cyber text-yellow-400">{score.toLocaleString()}</div>
                    </div>
                     <div className="grid grid-cols-2 gap-4">
                        <div className="bg-black/60 p-4 rounded-lg border border-white/10">
                            <div className="text-xs text-gray-400">GEMS</div>
                            <div className="text-xl md:text-2xl font-bold text-cyan-400">{gemsCollected}</div>
                        </div>
                        <div className="bg-black/60 p-4 rounded-lg border border-white/10">
                             <div className="text-xs text-gray-400">DISTANCE</div>
                            <div className="text-xl md:text-2xl font-bold text-purple-400">{Math.floor(distance)} LY</div>
                        </div>
                     </div>
                </div>

                {!hasSubmitted ? (
                    <form onSubmit={handleScoreSubmit} className="w-full max-w-md mb-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                        <div className="relative">
                            <input 
                                type="text" 
                                value={playerName}
                                onChange={(e) => setPlayerName(e.target.value.slice(0, 20))}
                                placeholder="ENTER YOUR NAME"
                                className="w-full bg-white/5 border border-white/20 rounded-xl px-4 py-4 text-white font-bold tracking-widest focus:outline-none focus:border-emerald-500 transition-all pr-12"
                                required
                            />
                            <button 
                                type="submit"
                                disabled={isSubmitting || !playerName.trim()}
                                className="absolute right-2 top-2 bottom-2 px-3 bg-emerald-500 text-black rounded-lg hover:bg-emerald-400 transition-colors disabled:opacity-50"
                            >
                                <Send className="w-5 h-5" />
                            </button>
                        </div>
                        <p className="text-[10px] text-gray-500 mt-2 text-center tracking-widest">SUBMIT SCORE TO LEADERBOARD</p>
                    </form>
                ) : (
                    <div className="w-full max-w-md mb-6 p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-center animate-in zoom-in-95 duration-300">
                        <p className="text-emerald-400 font-bold tracking-widest text-sm">SCORE SUBMITTED!</p>
                    </div>
                )}

                <Leaderboard entries={leaderboard} />

                <button 
                  onClick={() => { audio.init(); restartGame(); }}
                  className="mt-8 px-8 md:px-12 py-4 md:py-5 bg-white text-black font-black text-lg md:text-xl rounded hover:scale-105 transition-all shadow-[0_0_40px_rgba(255,255,255,0.3)] tracking-widest"
                >
                    RESTART JOURNEY
                </button>
            </div>
        </div>
    );
  }

  return (
    <div className={containerClass}>
        {/* Top Bar */}
        <div className="flex justify-between items-start w-full">
            <div className="flex flex-col">
                <div className="text-3xl md:text-5xl font-bold text-emerald-400 drop-shadow-[0_0_10px_#10b981] font-cyber">
                    {score.toLocaleString()}
                </div>
            </div>
            
            <div className="flex space-x-1 md:space-x-2">
                {[...Array(maxLives)].map((_, i) => (
                    <Heart 
                        key={i} 
                        className={`w-6 h-6 md:w-8 md:h-8 ${i < lives ? 'text-pink-500 fill-pink-500' : 'text-gray-800 fill-gray-800'} drop-shadow-[0_0_5px_#ff0054]`} 
                    />
                ))}
            </div>
        </div>
        
        {/* Level Indicator - Moved to Top Center aligned with Score/Hearts */}
        <div className="absolute top-5 left-1/2 transform -translate-x-1/2 text-sm md:text-lg text-emerald-300 font-bold tracking-wider font-mono bg-black/50 px-3 py-1 rounded-full border border-emerald-500/30 backdrop-blur-sm z-50">
            LEVEL {level} <span className="text-gray-500 text-xs md:text-sm">/ 3</span>
        </div>

        {/* Gemini Collection Status - Just below Top Bar */}
        <div className="absolute top-16 md:top-24 left-1/2 transform -translate-x-1/2 flex space-x-2 md:space-x-3">
            {target.map((char, idx) => {
                const isCollected = collectedLetters.includes(idx);
                const color = GEMINI_COLORS[idx];

                return (
                    <div 
                        key={idx}
                        style={{
                            borderColor: isCollected ? color : 'rgba(55, 65, 81, 1)',
                            // Use dark text (almost black) when collected to contrast with neon background
                            color: isCollected ? 'rgba(0, 0, 0, 0.8)' : 'rgba(55, 65, 81, 1)',
                            boxShadow: isCollected ? `0 0 20px ${color}` : 'none',
                            backgroundColor: isCollected ? color : 'rgba(0, 0, 0, 0.9)'
                        }}
                        className={`w-8 h-10 md:w-10 md:h-12 flex items-center justify-center border-2 font-black text-lg md:text-xl font-cyber rounded-lg transform transition-all duration-300`}
                    >
                        {char}
                    </div>
                );
            })}
        </div>

        {/* Bottom Overlay */}
        <div className="w-full flex justify-end items-end">
             <div className="flex items-center space-x-2 text-cyan-500 opacity-70">
                 <Zap className="w-4 h-4 md:w-6 md:h-6 animate-pulse" />
                 <span className="font-mono text-base md:text-xl">SPEED {Math.round((speed / RUN_SPEED_BASE) * 100)}%</span>
             </div>
        </div>
    </div>
  );
};
